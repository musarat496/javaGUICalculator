
package unit.converter;
import java.lang.Math.*;
public class temperature {
protected double t;
protected double a;
public temperature(){}
public void settemperature(double T){
this.t=T;}
public double initial(String iunit){
switch(iunit){
case "kelvin":t=t-273.15;
 return t;
 case "cntigrade":t=t;
 return t;
 case "fahrenheit":t=(t-32)*(5.0/9.0);
 return t;
 default:System.out.println("out of bounds");
}return t;}
public void convert(String unit){
switch(unit){
case "kelvin":a=t+273.15;
 break;
 case "centigrade":a=t;
 break;
 case "fahrenheit":a=((9.0/5.0)*t)+32;
 break;
 default:System.out.println("out of bounds");
 break;
}}
public double gettemperature(){
return a;}
}

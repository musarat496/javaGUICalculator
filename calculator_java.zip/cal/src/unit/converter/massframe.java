package unit.converter;

public class massframe extends javax.swing.JFrame {
public static double x;
    public massframe() {
        initComponents();
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel1 = new javax.swing.JLabel();
        massvalue = new javax.swing.JTextField();
        jPanel1 = new javax.swing.JPanel();
        miligramsI = new javax.swing.JRadioButton();
        gramsI = new javax.swing.JRadioButton();
        kilogramsI = new javax.swing.JRadioButton();
        ouncesI = new javax.swing.JRadioButton();
        poundsI = new javax.swing.JRadioButton();
        tons = new javax.swing.JRadioButton();
        jPanel2 = new javax.swing.JPanel();
        miligramsR = new javax.swing.JRadioButton();
        gramsR = new javax.swing.JRadioButton();
        kilogramsR = new javax.swing.JRadioButton();
        ouncesR = new javax.swing.JRadioButton();
        poundsR = new javax.swing.JRadioButton();
        tonsR = new javax.swing.JRadioButton();
        jLabel4 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        result = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jLabel1.setText("enter the mass");

        massvalue.setText("just the magnitude");

        miligramsI.setText("miligrams");
        miligramsI.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                miligramsIActionPerformed(evt);
            }
        });

        gramsI.setText("grams");
        gramsI.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                gramsIActionPerformed(evt);
            }
        });

        kilogramsI.setText("kilograms");
        kilogramsI.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                kilogramsIActionPerformed(evt);
            }
        });

        ouncesI.setText("ounces");
        ouncesI.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ouncesIActionPerformed(evt);
            }
        });

        poundsI.setText("pounds");
        poundsI.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                poundsIActionPerformed(evt);
            }
        });

        tons.setText("tons");
        tons.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                tonsActionPerformed(evt);
            }
        });

        miligramsR.setText("miligrams");
        miligramsR.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                miligramsRActionPerformed(evt);
            }
        });

        gramsR.setText("grams");
        gramsR.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                gramsRActionPerformed(evt);
            }
        });

        kilogramsR.setText("kilograms");
        kilogramsR.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                kilogramsRActionPerformed(evt);
            }
        });

        ouncesR.setText("ounces");
        ouncesR.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ouncesRActionPerformed(evt);
            }
        });

        poundsR.setText("pounds");
        poundsR.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                poundsRActionPerformed(evt);
            }
        });

        tonsR.setText("tons");
        tonsR.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                tonsRActionPerformed(evt);
            }
        });

        jLabel4.setText("the conversion unit");

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(miligramsR)
                    .addComponent(gramsR)
                    .addComponent(kilogramsR)
                    .addComponent(ouncesR)
                    .addComponent(poundsR)
                    .addComponent(tonsR)
                    .addComponent(jLabel4))
                .addGap(0, 37, Short.MAX_VALUE))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel4)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(miligramsR)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(gramsR)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(kilogramsR)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(ouncesR)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(poundsR)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(tonsR)
                .addContainerGap())
        );

        jLabel3.setText("the initial unit");

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(miligramsI)
                    .addComponent(ouncesI)
                    .addComponent(poundsI)
                    .addComponent(tons)
                    .addComponent(gramsI)
                    .addComponent(kilogramsI)
                    .addComponent(jLabel3))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 57, Short.MAX_VALUE)
                .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel3)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 7, Short.MAX_VALUE)
                .addComponent(miligramsI)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(gramsI)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(kilogramsI)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(ouncesI)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(poundsI)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(tons)
                .addContainerGap())
            .addComponent(jPanel2, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        result.setText("result of calculation");

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(10, 10, 10)
                        .addComponent(result))
                    .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(jLabel1)
                        .addGap(18, 18, 18)
                        .addComponent(massvalue, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(115, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(massvalue, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel1))
                .addGap(18, 18, 18)
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(result)
                .addContainerGap(48, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void miligramsIActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_miligramsIActionPerformed
       mass m1=new mass();
        String str=massvalue.getText();
        m1.setmass(Double.parseDouble(str));
        x=m1.initial("miligrams");
    }//GEN-LAST:event_miligramsIActionPerformed

    private void gramsIActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_gramsIActionPerformed
            mass m1=new mass();
        String str=massvalue.getText();
        m1.setmass(Double.parseDouble(str));
        x=m1.initial("grams");
    }//GEN-LAST:event_gramsIActionPerformed

    private void kilogramsIActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_kilogramsIActionPerformed
           mass m1=new mass();
        String str=massvalue.getText();
        m1.setmass(Double.parseDouble(str));
        x=m1.initial("kilograms");
    }//GEN-LAST:event_kilogramsIActionPerformed

    private void ouncesIActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ouncesIActionPerformed
           mass m1=new mass();
        String str=massvalue.getText();
        m1.setmass(Double.parseDouble(str));
        x=m1.initial("ounces");
    }//GEN-LAST:event_ouncesIActionPerformed

    private void poundsIActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_poundsIActionPerformed
            mass m1=new mass();
        String str=massvalue.getText();
        m1.setmass(Double.parseDouble(str));
        x=m1.initial("pounds");
    }//GEN-LAST:event_poundsIActionPerformed

    private void tonsActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_tonsActionPerformed
           mass m1=new mass();
        String str=massvalue.getText();
        m1.setmass(Double.parseDouble(str));
        x=m1.initial("tons");
    }//GEN-LAST:event_tonsActionPerformed

    private void miligramsRActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_miligramsRActionPerformed
    mass m1=new mass();
    m1.setmass(x);
    m1.convert("miligrams");
    result.setText("the converted value is "+Double.toString(m1.getmass()));
    }//GEN-LAST:event_miligramsRActionPerformed

    private void gramsRActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_gramsRActionPerformed
        mass m1=new mass();
    m1.setmass(x);
    m1.convert("grams");
    result.setText("the converted value is "+Double.toString(m1.getmass()));
    }//GEN-LAST:event_gramsRActionPerformed

    private void kilogramsRActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_kilogramsRActionPerformed
        mass m1=new mass();
    m1.setmass(x);
    m1.convert("kilograms");
    result.setText("the converted value is "+Double.toString(m1.getmass()));
    }//GEN-LAST:event_kilogramsRActionPerformed

    private void ouncesRActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ouncesRActionPerformed
        mass m1=new mass();
    m1.setmass(x);
    m1.convert("ounces");
    result.setText("the converted value is "+Double.toString(m1.getmass()));
    }//GEN-LAST:event_ouncesRActionPerformed

    private void poundsRActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_poundsRActionPerformed
        mass m1=new mass();
    m1.setmass(x);
    m1.convert("pounds");
    result.setText("the converted value is "+Double.toString(m1.getmass()));
    }//GEN-LAST:event_poundsRActionPerformed

    private void tonsRActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_tonsRActionPerformed
        mass m1=new mass();
    m1.setmass(x);
    m1.convert("tons");
    result.setText("the converted value is "+Double.toString(m1.getmass()));
    }//GEN-LAST:event_tonsRActionPerformed

    public static void main(String args[]) {
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new massframe().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JRadioButton gramsI;
    private javax.swing.JRadioButton gramsR;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JRadioButton kilogramsI;
    private javax.swing.JRadioButton kilogramsR;
    private javax.swing.JTextField massvalue;
    private javax.swing.JRadioButton miligramsI;
    private javax.swing.JRadioButton miligramsR;
    private javax.swing.JRadioButton ouncesI;
    private javax.swing.JRadioButton ouncesR;
    private javax.swing.JRadioButton poundsI;
    private javax.swing.JRadioButton poundsR;
    private javax.swing.JLabel result;
    private javax.swing.JRadioButton tons;
    private javax.swing.JRadioButton tonsR;
    // End of variables declaration//GEN-END:variables
}

package unit.converter;


import unit.converter.time;


public class timeframe extends javax.swing.JFrame {
public static double x;
    public timeframe() {
        initComponents();
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel1 = new javax.swing.JLabel();
        timevalue = new javax.swing.JTextField();
        jPanel1 = new javax.swing.JPanel();
        nanosecondsI = new javax.swing.JRadioButton();
        microsecondsI = new javax.swing.JRadioButton();
        jLabel2 = new javax.swing.JLabel();
        milisecondsI = new javax.swing.JRadioButton();
        secondsI = new javax.swing.JRadioButton();
        minuteI = new javax.swing.JRadioButton();
        hourI = new javax.swing.JRadioButton();
        dayI = new javax.swing.JRadioButton();
        weekI = new javax.swing.JRadioButton();
        monthI = new javax.swing.JRadioButton();
        yearI = new javax.swing.JRadioButton();
        jPanel2 = new javax.swing.JPanel();
        nanosecondsR = new javax.swing.JRadioButton();
        jLabel3 = new javax.swing.JLabel();
        microsecondsR = new javax.swing.JRadioButton();
        milisecondsR = new javax.swing.JRadioButton();
        secondsR = new javax.swing.JRadioButton();
        minuteR = new javax.swing.JRadioButton();
        hourR = new javax.swing.JRadioButton();
        dayR = new javax.swing.JRadioButton();
        weekR = new javax.swing.JRadioButton();
        monthR = new javax.swing.JRadioButton();
        yearR = new javax.swing.JRadioButton();
        result = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jLabel1.setText("enter the value");

        timevalue.setText("jTextField1");

        nanosecondsI.setText("nanoseconds");
        nanosecondsI.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                nanosecondsIActionPerformed(evt);
            }
        });

        microsecondsI.setText("microseconds");
        microsecondsI.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                microsecondsIActionPerformed(evt);
            }
        });

        jLabel2.setText("the initial unit");

        milisecondsI.setText("miliseconds");
        milisecondsI.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                milisecondsIActionPerformed(evt);
            }
        });

        secondsI.setText("seconds");
        secondsI.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                secondsIActionPerformed(evt);
            }
        });

        minuteI.setText("minute");
        minuteI.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                minuteIActionPerformed(evt);
            }
        });

        hourI.setText("hour");
        hourI.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                hourIActionPerformed(evt);
            }
        });

        dayI.setText("day");
        dayI.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                dayIActionPerformed(evt);
            }
        });

        weekI.setText("week");
        weekI.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                weekIActionPerformed(evt);
            }
        });

        monthI.setText("month");
        monthI.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                monthIActionPerformed(evt);
            }
        });

        yearI.setText("year");
        yearI.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                yearIActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel2)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(nanosecondsI)
                    .addComponent(microsecondsI)
                    .addComponent(milisecondsI)
                    .addComponent(secondsI)
                    .addComponent(minuteI)
                    .addComponent(hourI)
                    .addComponent(dayI)
                    .addComponent(weekI)
                    .addComponent(monthI)
                    .addComponent(yearI))
                .addGap(0, 47, Short.MAX_VALUE))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(4, 4, 4)
                .addComponent(jLabel2)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(nanosecondsI)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(microsecondsI)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(milisecondsI)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(secondsI)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(minuteI)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(hourI)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(dayI)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(weekI)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(monthI)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(yearI)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        nanosecondsR.setText("nanoseconds");
        nanosecondsR.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                nanosecondsRActionPerformed(evt);
            }
        });

        jLabel3.setText("the conversion unit");

        microsecondsR.setText("microseconds");
        microsecondsR.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                microsecondsRActionPerformed(evt);
            }
        });

        milisecondsR.setText("miliseconds");
        milisecondsR.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                milisecondsRActionPerformed(evt);
            }
        });

        secondsR.setText("seconds");
        secondsR.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                secondsRActionPerformed(evt);
            }
        });

        minuteR.setText("minute");
        minuteR.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                minuteRActionPerformed(evt);
            }
        });

        hourR.setText("hour");
        hourR.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                hourRActionPerformed(evt);
            }
        });

        dayR.setText("day");
        dayR.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                dayRActionPerformed(evt);
            }
        });

        weekR.setText("week");
        weekR.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                weekRActionPerformed(evt);
            }
        });

        monthR.setText("month");
        monthR.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                monthRActionPerformed(evt);
            }
        });

        yearR.setText("year");
        yearR.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                yearRActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(yearR)
                    .addComponent(monthR)
                    .addComponent(weekR)
                    .addComponent(dayR)
                    .addComponent(hourR)
                    .addComponent(minuteR)
                    .addComponent(secondsR)
                    .addComponent(milisecondsR)
                    .addComponent(microsecondsR)
                    .addComponent(nanosecondsR)
                    .addComponent(jLabel3))
                .addContainerGap(29, Short.MAX_VALUE))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(4, 4, 4)
                .addComponent(jLabel3)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(nanosecondsR)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(microsecondsR)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(milisecondsR)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(secondsR)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(minuteR)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(hourR)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(dayR)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(weekR)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(monthR)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(yearR)
                .addContainerGap(18, Short.MAX_VALUE))
        );

        result.setText("result of the calculation");

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(18, 18, 18)
                        .addComponent(jLabel1)
                        .addGap(18, 18, 18)
                        .addComponent(timevalue, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(result)))
                .addContainerGap(153, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel1)
                    .addComponent(timevalue, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addGap(18, 18, 18)
                .addComponent(result)
                .addContainerGap(15, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void nanosecondsIActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_nanosecondsIActionPerformed
     time t1=new time();
        String str=timevalue.getText();
        t1.settime(Double.parseDouble(str));
        x=t1.initial("nanoseconds");
    }//GEN-LAST:event_nanosecondsIActionPerformed

    private void microsecondsIActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_microsecondsIActionPerformed
     time t1=new time();
        String str=timevalue.getText();
        t1.settime(Double.parseDouble(str));
        x=t1.initial("microseconds");        // TODO add your handling code here:
    }//GEN-LAST:event_microsecondsIActionPerformed

    private void milisecondsIActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_milisecondsIActionPerformed
     time t1=new time();
        String str=timevalue.getText();
        t1.settime(Double.parseDouble(str));
        x=t1.initial("miliseconds");        // TODO add your handling code here:
    }//GEN-LAST:event_milisecondsIActionPerformed

    private void secondsIActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_secondsIActionPerformed
     time t1=new time();
        String str=timevalue.getText();
        t1.settime(Double.parseDouble(str));
        x=t1.initial("seconds");        // TODO add your handling code here:
    }//GEN-LAST:event_secondsIActionPerformed

    private void minuteIActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_minuteIActionPerformed
     time t1=new time();
        String str=timevalue.getText();
        t1.settime(Double.parseDouble(str));
        x=t1.initial("minute");        // TODO add your handling code here:
    }//GEN-LAST:event_minuteIActionPerformed

    private void hourIActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_hourIActionPerformed
     time t1=new time();
        String str=timevalue.getText();
        t1.settime(Double.parseDouble(str));
        x=t1.initial("hour");        // TODO add your handling code here:
    }//GEN-LAST:event_hourIActionPerformed

    private void dayIActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_dayIActionPerformed
     time t1=new time();
        String str=timevalue.getText();
        t1.settime(Double.parseDouble(str));
        x=t1.initial("day");        // TODO add your handling code here:
    }//GEN-LAST:event_dayIActionPerformed

    private void weekIActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_weekIActionPerformed
     time t1=new time();
        String str=timevalue.getText();
        t1.settime(Double.parseDouble(str));
        x=t1.initial("week");        // TODO add your handling code here:
    }//GEN-LAST:event_weekIActionPerformed

    private void monthIActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_monthIActionPerformed
     time t1=new time();
        String str=timevalue.getText();
        t1.settime(Double.parseDouble(str));
        x=t1.initial("month");        // TODO add your handling code here:
    }//GEN-LAST:event_monthIActionPerformed

    private void yearIActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_yearIActionPerformed
     time t1=new time();
        String str=timevalue.getText();
        t1.settime(Double.parseDouble(str));
        x=t1.initial("year");        // TODO add your handling code here:
    }//GEN-LAST:event_yearIActionPerformed

    private void nanosecondsRActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_nanosecondsRActionPerformed
    time t1=new time();
    t1.settime(x);
    t1.convert("nanoseconds");
    result.setText("the converted value is "+Double.toString(t1.gettime()));        // TODO add your handling code here:
    }//GEN-LAST:event_nanosecondsRActionPerformed

    private void microsecondsRActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_microsecondsRActionPerformed
 time t1=new time();
    t1.settime(x);
    t1.convert("microseconds");
    result.setText("the converted value is "+Double.toString(t1.gettime()));         // TODO add your handling code here:
    }//GEN-LAST:event_microsecondsRActionPerformed

    private void milisecondsRActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_milisecondsRActionPerformed
 time t1=new time();
    t1.settime(x);
    t1.convert("miliseconds");
    result.setText("the converted value is "+Double.toString(t1.gettime()));         // TODO add your handling code here:
    }//GEN-LAST:event_milisecondsRActionPerformed

    private void secondsRActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_secondsRActionPerformed
 time t1=new time();
    t1.settime(x);
    t1.convert("seconds");
    result.setText("the converted value is "+Double.toString(t1.gettime()));         // TODO add your handling code here:
    }//GEN-LAST:event_secondsRActionPerformed

    private void minuteRActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_minuteRActionPerformed
 time t1=new time();
    t1.settime(x);
    t1.convert("minute");
    result.setText("the converted value is "+Double.toString(t1.gettime()));         // TODO add your handling code here:
    }//GEN-LAST:event_minuteRActionPerformed

    private void hourRActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_hourRActionPerformed
 time t1=new time();
    t1.settime(x);
    t1.convert("hour");
    result.setText("the converted value is "+Double.toString(t1.gettime()));         // TODO add your handling code here:
    }//GEN-LAST:event_hourRActionPerformed

    private void dayRActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_dayRActionPerformed
 time t1=new time();
    t1.settime(x);
    t1.convert("day");
    result.setText("the converted value is "+Double.toString(t1.gettime()));         // TODO add your handling code here:
    }//GEN-LAST:event_dayRActionPerformed

    private void weekRActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_weekRActionPerformed
 time t1=new time();
    t1.settime(x);
    t1.convert("week");
    result.setText("the converted value is "+Double.toString(t1.gettime()));         // TODO add your handling code here:
    }//GEN-LAST:event_weekRActionPerformed

    private void monthRActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_monthRActionPerformed
 time t1=new time();
    t1.settime(x);
    t1.convert("month");
    result.setText("the converted value is "+Double.toString(t1.gettime()));         // TODO add your handling code here:
    }//GEN-LAST:event_monthRActionPerformed

    private void yearRActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_yearRActionPerformed
 time t1=new time();
    t1.settime(x);
    t1.convert("year");
    result.setText("the converted value is "+Double.toString(t1.gettime()));         // TODO add your handling code here:
    }//GEN-LAST:event_yearRActionPerformed

    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(timeframe.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(timeframe.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(timeframe.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(timeframe.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new timeframe().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JRadioButton dayI;
    private javax.swing.JRadioButton dayR;
    private javax.swing.JRadioButton hourI;
    private javax.swing.JRadioButton hourR;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JRadioButton microsecondsI;
    private javax.swing.JRadioButton microsecondsR;
    private javax.swing.JRadioButton milisecondsI;
    private javax.swing.JRadioButton milisecondsR;
    private javax.swing.JRadioButton minuteI;
    private javax.swing.JRadioButton minuteR;
    private javax.swing.JRadioButton monthI;
    private javax.swing.JRadioButton monthR;
    private javax.swing.JRadioButton nanosecondsI;
    private javax.swing.JRadioButton nanosecondsR;
    private javax.swing.JLabel result;
    private javax.swing.JRadioButton secondsI;
    private javax.swing.JRadioButton secondsR;
    private javax.swing.JTextField timevalue;
    private javax.swing.JRadioButton weekI;
    private javax.swing.JRadioButton weekR;
    private javax.swing.JRadioButton yearI;
    private javax.swing.JRadioButton yearR;
    // End of variables declaration//GEN-END:variables
}

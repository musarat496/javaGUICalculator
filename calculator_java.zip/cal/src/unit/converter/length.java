
package unit.converter;
import javax.swing.JRadioButton;
public class length{
protected double l;
protected double a;
public length(){}
public void setlength(double L){
this.l=L;}    
public double initial(String iunit){
switch(iunit)
{
case "milimeter":
  l=l/1000;
 return l;
case "centimeter":
  l=l/100;
 return l;
case "meter":
  l=l;
 return l;
case "kilometer":
  l=l*1000;
 return l;   
case "foot":
  l=l/3.281;
 return l;
case "yard":
  l=l/1.094;
 return l;
case "inches":
  l=l/39.37;
 return l;
case "miles":
  l=l*1609.344;
 return l;
default:
System.out.println("out of bounds");
}return l;}
public void convert(String unit){
switch(unit)
{case "milimeter":
a=l*1000;
break;
case "centimeter":
a=l*100;
break;
case "meter":
a=l;
break;
case "kilometer":
a=l/1000;
break;
case "foot":
a=l*3.281;
break;
case "yard":
a=l*1.094;
break;
case "inches":
a=l*39.37;
break;
case "miles":
    a=l/1609.344;
    break;
default:
System.out.println("out of bounds");
break;    
}}
public double getlength(){
return a;}

    void initial(JRadioButton nanometer) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
}










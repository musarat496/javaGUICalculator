
package unit.converter;
import static java.lang.Math.*;
public class acceleration {
    protected double ac;
    protected double a;
    public acceleration(){}
    public void setacceleration(double AC){
    this.ac=AC;}
    public double initial(String iunit){
    switch(iunit){
    case "centimeter/sec^2":ac=ac*0.01;
  return ac;
  case "meter/sec^2":ac=ac*1;
  return ac;
  case "kilometer/hour^2":ac=ac*(7.71604938/pow(10,5));
  return ac;
  case "foot/sec^2":ac=ac*0.3048;
  return ac;
  case "yards/sec^2":ac=ac*0.9144;
  return ac;
  case "miles/hour^2":ac=ac*0.000124177778;
  return ac;
  default:System.out.println("out of bounds");
}return ac;}
    public void convert(String unit){
    switch(unit){
    case "centimeter/sec^2":a=ac/0.01;
  break;
  case "meter/sec^2":a=ac;
  break;
  case "kilometer/hour^2":a=ac/(7.71604938/pow(10,5));
  break;
  case "foot/sec^2":a=ac/0.3048;
  break;
  case "yards/sec^2":a=ac/0.9144;
  break;
  case "miles/hour^2":a=ac/0.000124177778;
  break;
  default:System.out.println("out of bounds");
  break;
}}
public double getacceleration(){
return a;}    
}

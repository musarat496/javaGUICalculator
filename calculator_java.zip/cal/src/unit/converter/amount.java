
package unit.converter;

import static java.lang.Math.*;
public class amount {
protected double A;
protected double a;
public amount(){}
public void setamount(double AM){
this.A=AM;}
public double initial(String iunit){
switch(iunit){
case "moles":A=A;
return A;
 case "particles":A=A/(6.023*pow(10,23));
     return A;
 default:System.out.println("out of bounds");
}return A;}
public void convert(String unit){
switch(unit){
case "moles":a=A;
  break;
  case "particles":a=A*(6.023*pow(10,23));
  break;
  default:System.out.println("out of bounds");
  break;
}}
public double getamount(){
return a;}
}

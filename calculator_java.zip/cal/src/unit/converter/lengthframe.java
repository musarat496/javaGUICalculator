
package unit.converter;

public class lengthframe extends javax.swing.JFrame {
public static double x;
    public lengthframe() {
        initComponents();
     
    }

   
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel2 = new javax.swing.JLabel();
        input = new javax.swing.JLabel();
        lengthvalue = new javax.swing.JTextField();
        jPanel1 = new javax.swing.JPanel();
        kilometerI = new javax.swing.JRadioButton();
        centimeterI = new javax.swing.JRadioButton();
        meterI = new javax.swing.JRadioButton();
        footI = new javax.swing.JRadioButton();
        yardsI = new javax.swing.JRadioButton();
        inchesI = new javax.swing.JRadioButton();
        milesI = new javax.swing.JRadioButton();
        milimeterI = new javax.swing.JRadioButton();
        jPanel2 = new javax.swing.JPanel();
        milimeterR = new javax.swing.JRadioButton();
        centimeterR = new javax.swing.JRadioButton();
        kilometerR = new javax.swing.JRadioButton();
        footR = new javax.swing.JRadioButton();
        yardsR = new javax.swing.JRadioButton();
        inchesR = new javax.swing.JRadioButton();
        milesR = new javax.swing.JRadioButton();
        meterR = new javax.swing.JRadioButton();
        result = new javax.swing.JLabel();
        jLabel1 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();

        jLabel2.setText("jLabel2");

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        lengthvalue.setText("just the magnitude");
        lengthvalue.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                lengthvalueActionPerformed(evt);
            }
        });

        kilometerI.setText("kilometer");
        kilometerI.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                kilometerIActionPerformed(evt);
            }
        });

        centimeterI.setText("centimeter");
        centimeterI.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                centimeterIActionPerformed(evt);
            }
        });

        meterI.setText("meter");
        meterI.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                meterIActionPerformed(evt);
            }
        });

        footI.setText("foot");
        footI.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                footIActionPerformed(evt);
            }
        });

        yardsI.setText("yards");
        yardsI.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                yardsIActionPerformed(evt);
            }
        });

        inchesI.setText("inches");
        inchesI.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                inchesIActionPerformed(evt);
            }
        });

        milesI.setText("miles");
        milesI.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                milesIActionPerformed(evt);
            }
        });

        milimeterI.setText("milimeter");
        milimeterI.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                milimeterIActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                        .addGroup(jPanel1Layout.createSequentialGroup()
                            .addComponent(footI, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addGap(93, 93, 93))
                        .addComponent(centimeterI, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(meterI, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addComponent(kilometerI)
                    .addComponent(yardsI)
                    .addComponent(inchesI)
                    .addComponent(milesI)
                    .addComponent(milimeterI))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(milimeterI)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(centimeterI)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(meterI)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(kilometerI)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(footI, javax.swing.GroupLayout.PREFERRED_SIZE, 23, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(yardsI)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(inchesI)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(milesI)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        milimeterR.setText("milimeter");
        milimeterR.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                milimeterRActionPerformed(evt);
            }
        });

        centimeterR.setText("centimeter");
        centimeterR.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                centimeterRActionPerformed(evt);
            }
        });

        kilometerR.setText("kilometer");
        kilometerR.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                kilometerRActionPerformed(evt);
            }
        });

        footR.setText("foot");
        footR.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                footRActionPerformed(evt);
            }
        });

        yardsR.setText("yards");
        yardsR.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                yardsRActionPerformed(evt);
            }
        });

        inchesR.setText("inches");
        inchesR.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                inchesRActionPerformed(evt);
            }
        });

        milesR.setText("miles");
        milesR.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                milesRActionPerformed(evt);
            }
        });

        meterR.setText("meter");
        meterR.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                meterRActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(milimeterR)
                            .addComponent(centimeterR)
                            .addComponent(kilometerR)
                            .addComponent(footR)
                            .addComponent(yardsR)
                            .addComponent(inchesR)
                            .addComponent(milesR))
                        .addGap(0, 87, Short.MAX_VALUE))
                    .addComponent(meterR, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap())
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addComponent(milimeterR)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(centimeterR)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(meterR)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(kilometerR)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(footR)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(yardsR)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(inchesR)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(milesR))
        );

        result.setText("result of calculation");

        jLabel1.setText("enter the length");

        jLabel3.setText("the initial unit");

        jLabel4.setText("the conversion unit");

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, 118, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(input)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(jLabel1)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(lengthvalue, javax.swing.GroupLayout.PREFERRED_SIZE, 108, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(result, javax.swing.GroupLayout.PREFERRED_SIZE, 348, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(jLabel3)
                        .addGap(79, 79, 79)
                        .addComponent(jLabel4)))
                .addContainerGap(45, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 20, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(lengthvalue, javax.swing.GroupLayout.PREFERRED_SIZE, 26, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addGap(50, 50, 50)
                                .addComponent(input))
                            .addGroup(layout.createSequentialGroup()
                                .addGap(18, 18, 18)
                                .addComponent(jLabel3)
                                .addGap(2, 2, 2)
                                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(result, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addGap(18, 18, 18))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(18, 18, 18)
                        .addComponent(jLabel4)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void kilometerIActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_kilometerIActionPerformed
   length l2=new length();
        String str=lengthvalue.getText();
        l2.setlength(Double.parseDouble(str));
        x=l2.initial("kilometer");
   
   
    
     
    }//GEN-LAST:event_kilometerIActionPerformed

    private void lengthvalueActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_lengthvalueActionPerformed
     
       
    
    }//GEN-LAST:event_lengthvalueActionPerformed

    private void meterRActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_meterRActionPerformed
    length l2=new length();
    l2.setlength(x);
    l2.convert("meter");
    result.setText("the converted value is "+Double.toString(l2.getlength()));
    }//GEN-LAST:event_meterRActionPerformed

    private void milimeterIActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_milimeterIActionPerformed
       length l2=new length();
        String str=lengthvalue.getText();
        l2.setlength(Double.parseDouble(str));
        x=l2.initial("milimeter");
    }//GEN-LAST:event_milimeterIActionPerformed

    private void centimeterIActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_centimeterIActionPerformed
       length l2=new length();
        String str=lengthvalue.getText();
        l2.setlength(Double.parseDouble(str));
        x=l2.initial("centimeter");
    }//GEN-LAST:event_centimeterIActionPerformed

    private void meterIActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_meterIActionPerformed
        length l2=new length();
        String str=lengthvalue.getText();
        l2.setlength(Double.parseDouble(str));
        x=l2.initial("meter");
    }//GEN-LAST:event_meterIActionPerformed

    private void footIActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_footIActionPerformed
       length l2=new length();
        String str=lengthvalue.getText();
        l2.setlength(Double.parseDouble(str));
        x=l2.initial("foot");
    }//GEN-LAST:event_footIActionPerformed

    private void yardsIActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_yardsIActionPerformed
          length l2=new length();
        String str=lengthvalue.getText();
        l2.setlength(Double.parseDouble(str));
        x=l2.initial("yard");
    }//GEN-LAST:event_yardsIActionPerformed

    private void inchesIActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_inchesIActionPerformed
          length l2=new length();
        String str=lengthvalue.getText();
        l2.setlength(Double.parseDouble(str));
        x=l2.initial("inches");
    }//GEN-LAST:event_inchesIActionPerformed

    private void milesIActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_milesIActionPerformed
        length l2=new length();
        String str=lengthvalue.getText();
        l2.setlength(Double.parseDouble(str));
        x=l2.initial("miles");
    }//GEN-LAST:event_milesIActionPerformed

    private void milimeterRActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_milimeterRActionPerformed
    length l2=new length();
    l2.setlength(x);
    l2.convert("milimeter");
    result.setText("the converted value is "+Double.toString(l2.getlength()));
    }//GEN-LAST:event_milimeterRActionPerformed

    private void centimeterRActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_centimeterRActionPerformed
      length l2=new length();
    l2.setlength(x);
    l2.convert("centimeter");
    result.setText("the converted value is "+Double.toString(l2.getlength()));
    }//GEN-LAST:event_centimeterRActionPerformed

    private void kilometerRActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_kilometerRActionPerformed
     length l2=new length();
    l2.setlength(x);
    l2.convert("kilometer");
    result.setText("the converted value is "+Double.toString(l2.getlength()));
    }//GEN-LAST:event_kilometerRActionPerformed

    private void footRActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_footRActionPerformed
    length l2=new length();
    l2.setlength(x);
    l2.convert("foot");
    result.setText("the converted value is "+Double.toString(l2.getlength()));
    }//GEN-LAST:event_footRActionPerformed

    private void yardsRActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_yardsRActionPerformed
     length l2=new length();
    l2.setlength(x);
    l2.convert("yard");
    result.setText("the converted value is "+Double.toString(l2.getlength()));
    }//GEN-LAST:event_yardsRActionPerformed

    private void inchesRActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_inchesRActionPerformed
    length l2=new length();
    l2.setlength(x);
    l2.convert("inches");
    result.setText("the converted value is "+Double.toString(l2.getlength()));
    }//GEN-LAST:event_inchesRActionPerformed

    private void milesRActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_milesRActionPerformed
    length l2=new length();
    l2.setlength(x);
    l2.convert("miles");
    result.setText("the converted value is "+Double.toString(l2.getlength()));
    }//GEN-LAST:event_milesRActionPerformed

    public static void main(String args[]) {
        
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new lengthframe().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JRadioButton centimeterI;
    private javax.swing.JRadioButton centimeterR;
    private javax.swing.JRadioButton footI;
    private javax.swing.JRadioButton footR;
    private javax.swing.JRadioButton inchesI;
    private javax.swing.JRadioButton inchesR;
    private javax.swing.JLabel input;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JRadioButton kilometerI;
    private javax.swing.JRadioButton kilometerR;
    private javax.swing.JTextField lengthvalue;
    private javax.swing.JRadioButton meterI;
    private javax.swing.JRadioButton meterR;
    private javax.swing.JRadioButton milesI;
    private javax.swing.JRadioButton milesR;
    private javax.swing.JRadioButton milimeterI;
    private javax.swing.JRadioButton milimeterR;
    private javax.swing.JLabel result;
    private javax.swing.JRadioButton yardsI;
    private javax.swing.JRadioButton yardsR;
    // End of variables declaration//GEN-END:variables

    private static class jTextField {

        public jTextField() {
        }
    }
}

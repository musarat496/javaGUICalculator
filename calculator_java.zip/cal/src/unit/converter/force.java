
package unit.converter;

import static java.lang.Math.pow;

public class force {
protected double f;
public force(){}
public void setforce(double F){
this.f=F;}
public double initial(String iunit){
switch(iunit){
case "kilonewton":f=f*1000;
 return f;
 case "gram-force":f=f*0.00980665;
 return f;
 case "kilogram-force":f=f*9.80665;
 return f;
 case "ton-force":f=f*9806.65;
 return f;
 case "giganewton":f=f*1000000000;
 return f;
 case "meganewton":f=f*1000000; 
 return f;
 case "dynes":f=f/pow(10,5);
 return f;
 case "joules/meter":f=f;
 return f;
 case "pound-force":f=f*4.4482216153;
 return f;
 case "ounce-force":f=f*0.278013851;
 return f;
 case "pound foot/sec^2":f=f*0.1382549544;
 return f;
 case "newton":f=f;
 return f;
 default:System.out.println("out of bounds");
}return f;}
public void convert(String unit){
switch(unit){
 case "kilonewton":f=f/1000;
 break;
 case "gram-force":f=f/0.00980665;
 break;
 case "kilogram-force":f=f/9.80665;
 break;
 case "ton-force":f=f/9806.65;
 break;
 case "giganewton":f=f/1000000000;
 break;
 case "meganewton":f=f/1000000; 
 break;
 case "dynes":f=f*pow(10,5);
 break;
 case "joules/meter":f=f*1;
 break;
 case "pound-force":f=f/4.4482216153;
 break;
 case "ounce-force":f=f/0.278013851;
 break;
 case "pound foot/sec^2":f=f/0.1382549544;
 break;
 case "newton":f=f*1;
 break;
 default:System.out.println("out of bounds");
     break;
}
}
public double getforce(){
return f;}
}


package unit.converter;
import static java.lang.Math.*;
public class current {
    protected double c;
    protected double a;
    public current(){}
    public void setcurrent(double C){
    this.c=C;}
    public double initial(String iunit){
    switch(iunit){
    case "microampere":c=c/(pow(10,6));
        return c;
 case "miliampere":c=c/(pow(10,3));
return c;
 case "ampere":c=c;
 return c;
 case "kiloampere":c=c*1000;
 return c;
 case "megaampere":c=c*(pow(10,6));
 return c;
 default:System.out.println("out of bounds");
}return c;
    }
    public void convert(String unit){
switch(unit){
    case "microampere":a=c*(pow(10,6));
 break;
 case "miliampere":a=c*(pow(10,3));
 break;
 case "ampere":a=c;
 break;
 case "kiloampere":a=c/1000;
 break;
 case "megaampere":a=c/(pow(10,6));
 break;
 default:System.out.println("out of bounds");
 break;
}}
public double getcurrent(){
return a;}    
}


package unit.converter;
import static java.lang.Math.*;
public class area {
protected double ar;
protected double a;
public area(){
}
public void setarea(double AR){
this.ar=AR;}
public double initial(String iunit){
switch(iunit){
case "milimeter squared":ar=ar/pow(10,6);
return ar;
 case "centimeter squared":ar=ar/pow(10,4);
return ar;
 case "meter squared":ar=ar;
return ar;
 case "kilometer squared":ar=ar*pow(10,6);
return ar;
 case "foot squared":ar=ar*0.09290304;
return ar;
 case "yard squared":ar=ar*0.83612736;
return ar;
 case "inches squared":ar=ar*2589988.110336;
return ar;
 case "miles squared":ar=ar*2589988.110336; 
return ar;
 case "acres":ar=ar*4046.8564224;
return ar;
 default:System.out.println("out of bounds");
}return ar;}
public void convert(String unit){
switch(unit){
case "milimeter squared":a=ar*pow(10,6);
 break;
 case "centimeter squared":a=ar*pow(10,4);
 break;
 case "meter squared":a=ar;
 break;
 case "kilometer squared":a=ar/pow(10,6);
 break;
 case "foot squared":a=ar/0.09290304;
 break;
 case "yard squared":a=ar/0.83612736;
 break;
 case "inches squared":a=ar/2589988.110336;
 break;
 case "miles squared":a=ar/2589988.110336; 
 break;	
 case "acres":a=ar/4046.8564224;
 break;
 default:System.out.println("out of bounds");
 break;
}}
public double getarea(){
return a;}
}

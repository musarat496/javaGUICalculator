
package unit.converter;
import java.util.*;
public class mass extends UnitConverter{
private double m;
private double a;
public mass(){}
public void setmass(double M){
this.m=M;
}
public double initial(String iunit){
switch(iunit){
case "miligrams":m=m/1000;
return m;
case "grams":m=m;
return m;
case "kilograms":m=m*1000;
return m;
case "ounces":m=m*28.35;
return m;
case "pounds":m=m*453.592;
return m;
case "tons":m=m*907184.74;
return m;
default:System.out.println("out of bounds");
}
return m;
}
public void convert(String unit){
switch(unit){
case "miligrams":a=m*1000;
break;
case "grams":a=m;
break;
case "kilograms":a=m/1000;
break;
case "ounces":a=m/28.35;
break;
case "pounds":a=m/453.592;
break;
case "tons":a=m/907184.74;
break;
default:System.out.println("out of bounds");
break;
}
}
public double getmass(){
return a;}
}

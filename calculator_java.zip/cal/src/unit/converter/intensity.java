
package unit.converter;
public class intensity {
protected double i;
protected double a;
public intensity(){}
public void setintensity(double IN){
this.i=IN;}
public double initial(String iunit){
switch(iunit){
case "candle(german)":i=i*1.0526315789;
 return i;
 case "candle(UK)":i=i*1.0416666667;
 return i;
 case "carcel unit":i=i*9.610000003;
 return i;
 case "decimal candle":i=i*1;
 return i;
 case "hefner candle":i=i*0.9000000001;
 return i;
 case "lumen/steradian":i=i*1;
 return i;
 case "pentane candle":i=i*10;
 return i;
 default:System.out.println("out of bounds");
}return i;}
public void convert(String unit){
switch(unit){
case "candle(german)":a=i/1.0526315789;
 break;
 case "candle(UK)":a=i/1.0416666667;
 break;
 case "carcel unit":a=i/9.610000003;
 break;
 case "decimal candle":a=i;
 break;
 case "hefner candle":a=i/0.9000000001;
 break;
 case "lumen/steradian":a=i;
 break;
 case "pentane candle":a=i/10;
 break;
 default:System.out.println("out of bounds");
 break;
}}
public double getintensity(){
return a;}}

package unit.converter;


import unit.converter.current;


public class currentframe extends javax.swing.JFrame {
public static double x;
    public currentframe() {
        initComponents();
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel1 = new javax.swing.JLabel();
        currentvalue = new javax.swing.JTextField();
        jPanel1 = new javax.swing.JPanel();
        jLabel2 = new javax.swing.JLabel();
        microampereI = new javax.swing.JRadioButton();
        miliampereI = new javax.swing.JRadioButton();
        ampereI = new javax.swing.JRadioButton();
        kiloampereI = new javax.swing.JRadioButton();
        megaampereI = new javax.swing.JRadioButton();
        jPanel2 = new javax.swing.JPanel();
        jLabel3 = new javax.swing.JLabel();
        microampereR = new javax.swing.JRadioButton();
        miliampereR = new javax.swing.JRadioButton();
        ampereR = new javax.swing.JRadioButton();
        kiloampereR = new javax.swing.JRadioButton();
        megaampereR = new javax.swing.JRadioButton();
        result = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jLabel1.setText("enter the value");

        currentvalue.setText("jTextField1");

        jLabel2.setText("the initilal unit");

        microampereI.setText("microampere");
        microampereI.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                microampereIActionPerformed(evt);
            }
        });

        miliampereI.setText("miliampere");
        miliampereI.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                miliampereIActionPerformed(evt);
            }
        });

        ampereI.setText("ampere");
        ampereI.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ampereIActionPerformed(evt);
            }
        });

        kiloampereI.setText("kiloampere");
        kiloampereI.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                kiloampereIActionPerformed(evt);
            }
        });

        megaampereI.setText("megaampere");
        megaampereI.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                megaampereIActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel2)
                    .addComponent(microampereI)
                    .addComponent(miliampereI)
                    .addComponent(ampereI)
                    .addComponent(kiloampereI)
                    .addComponent(megaampereI))
                .addGap(0, 0, Short.MAX_VALUE))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addComponent(jLabel2)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(microampereI)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(miliampereI)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(ampereI)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(kiloampereI)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(megaampereI)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        jLabel3.setText("the conversion unit");

        microampereR.setText("microampere");
        microampereR.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                microampereRActionPerformed(evt);
            }
        });

        miliampereR.setText("miliampere");
        miliampereR.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                miliampereRActionPerformed(evt);
            }
        });

        ampereR.setText("ampere");
        ampereR.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ampereRActionPerformed(evt);
            }
        });

        kiloampereR.setText("kiloampere");
        kiloampereR.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                kiloampereRActionPerformed(evt);
            }
        });

        megaampereR.setText("megaampere");
        megaampereR.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                megaampereRActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel3)
                    .addComponent(microampereR)
                    .addComponent(miliampereR)
                    .addComponent(ampereR)
                    .addComponent(kiloampereR)
                    .addComponent(megaampereR))
                .addGap(0, 26, Short.MAX_VALUE))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addComponent(jLabel3)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(microampereR)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(miliampereR)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(ampereR)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(kiloampereR)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(megaampereR)
                .addGap(0, 0, Short.MAX_VALUE))
        );

        result.setText("result of the calculation");

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(jLabel1)
                        .addGap(18, 18, 18)
                        .addComponent(currentvalue, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(result, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                        .addGap(78, 78, 78)
                        .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(82, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(currentvalue, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel1))
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addGap(35, 35, 35)
                .addComponent(result)
                .addContainerGap(64, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void microampereIActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_microampereIActionPerformed
        current c1=new current();
        String str=currentvalue.getText();
        c1.setcurrent(Double.parseDouble(str));
        x=c1.initial("microampere");          // TODO add your handling code here:
    }//GEN-LAST:event_microampereIActionPerformed

    private void miliampereIActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_miliampereIActionPerformed
        current c1=new current();
        String str=currentvalue.getText();
        c1.setcurrent(Double.parseDouble(str));
        x=c1.initial("miliampere");         // TODO add your handling code here:
    }//GEN-LAST:event_miliampereIActionPerformed

    private void ampereIActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ampereIActionPerformed
             current c1=new current();
        String str=currentvalue.getText();
        c1.setcurrent(Double.parseDouble(str));
        x=c1.initial("ampere");    // TODO add your handling code here:        // TODO add your handling code here:
    }//GEN-LAST:event_ampereIActionPerformed

    private void kiloampereIActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_kiloampereIActionPerformed
        current c1=new current();
        String str=currentvalue.getText();
        c1.setcurrent(Double.parseDouble(str));
        x=c1.initial("kiloampere");         // TODO add your handling code here:
    }//GEN-LAST:event_kiloampereIActionPerformed

    private void megaampereIActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_megaampereIActionPerformed
        current c1=new current();
        String str=currentvalue.getText();
        c1.setcurrent(Double.parseDouble(str));
        x=c1.initial("megaampere");         // TODO add your handling code here:
    }//GEN-LAST:event_megaampereIActionPerformed

    private void microampereRActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_microampereRActionPerformed
current c1=new current();
    c1.setcurrent(x);
    c1.convert("microampere");
    result.setText("the converted value is "+Double.toString(c1.getcurrent()));         // TODO add your handling code here:
    }//GEN-LAST:event_microampereRActionPerformed

    private void miliampereRActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_miliampereRActionPerformed
    current c1=new current();
    c1.setcurrent(x);
    c1.convert("miliampere");
    result.setText("the converted value is "+Double.toString(c1.getcurrent()));    // TODO add your handling code here:
    }//GEN-LAST:event_miliampereRActionPerformed

    private void ampereRActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ampereRActionPerformed
current c1=new current();
    c1.setcurrent(x);
    c1.convert("ampere");
    result.setText("the converted value is "+Double.toString(c1.getcurrent()));        // TODO add your handling code here:
    }//GEN-LAST:event_ampereRActionPerformed

    private void kiloampereRActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_kiloampereRActionPerformed
current c1=new current();
    c1.setcurrent(x);
    c1.convert("kiloampere");
    result.setText("the converted value is "+Double.toString(c1.getcurrent()));        // TODO add your handling code here:
    }//GEN-LAST:event_kiloampereRActionPerformed

    private void megaampereRActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_megaampereRActionPerformed
current c1=new current();
    c1.setcurrent(x);
    c1.convert("megaampere");
    result.setText("the converted value is "+Double.toString(c1.getcurrent()));        // TODO add your handling code here:
    }//GEN-LAST:event_megaampereRActionPerformed

    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(currentframe.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(currentframe.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(currentframe.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(currentframe.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new currentframe().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JRadioButton ampereI;
    private javax.swing.JRadioButton ampereR;
    private javax.swing.JTextField currentvalue;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JRadioButton kiloampereI;
    private javax.swing.JRadioButton kiloampereR;
    private javax.swing.JRadioButton megaampereI;
    private javax.swing.JRadioButton megaampereR;
    private javax.swing.JRadioButton microampereI;
    private javax.swing.JRadioButton microampereR;
    private javax.swing.JRadioButton miliampereI;
    private javax.swing.JRadioButton miliampereR;
    private javax.swing.JLabel result;
    // End of variables declaration//GEN-END:variables
}


package unit.converter;
import static java.lang.Math.*;
public class pressure {
protected double p;
protected double a;
public pressure(){
}public void setpressure(double P){
this.p=P;}
public double initial(String iunit){
switch(iunit){
case "pascal":p=p;
return p;
 case "bar":p=p*pow(10,5);
return p;
 case "torr":p=p*133.322368421;
return p;
 case "atm":p=p*101325;
return p;
 case "pounds/square inch":p=p*6894.757293168;
return p;
 default:System.out.println("out of bounds");
}return p;}    
public void convert(String unit){
switch(unit){
case "pascal":a=p;
 break;
 case "bar":a=p/pow(10,5);
 break;
 case "torr":a=p/133.322368421;
 break;
 case "atm":a=p/101325;
 break;
 case "poounds/square inch":a=p/6894.757293168;
 break;
 default:System.out.println("out of bounds");
 break;
}}
public double getpressure(){
return a;}
}

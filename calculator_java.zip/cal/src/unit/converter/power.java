
package unit.converter;
import static java.lang.Math.*;
public class power {
protected double p;
protected double a;
public power(){
}
public void setpower(double P){
this.p=P;}
public double initial(String iunit){
switch(iunit){
case "watt":p=p;
return p;
 case "kilowatt":p=p*1000;
return p;
 case "erg":p=p*9.80665;
return p;
 case "kilogram-force meter/sec":p=p*1.355820;
return p;
 case "horsepower":p=p*746;
return p;
 default:System.out.println("out of bounds");
 }return p;}
public void convert(String unit){
switch(unit){
    case "watt":a=p;
 break;
 case "kilowatt":a=p/1000;
 break;
 case "erg":a=p/9.80665;
 break;
 case "kilogram-force meter/sec":a=p/1.355820;
 break;
 case "horsepower":a=p/746;
 break;
 default:System.out.println("out of bounds");
 break;
}}
public double getpower(){
return a;}
}

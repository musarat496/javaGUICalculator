
package unit.converter;
import static java.lang.Math.*;
import java.util.*;
public class time {
protected double t;
protected double a;
public time(){}
public void settime(double T){
this.t=T;}
public double initial(String iunit){
switch(iunit){
case "nanoseconds":
    t=t/(pow(10,9));
return t;
case "microseconds":
    t=t/(pow(10,6));
return t;
case "miliseconds":t=t/1000;
return t;
case "seconds":t=t;
return t;
case "minute":t=t*60;
return t;
case "hour":t=t*3600;
return t;
case "day":t=t*86400; 
return t;
case "week":t=t*604800;
return t;
case "month":t=t*(pow(2.638,6));
return t;
case "year":t=t*(pow(3.154,7));
return t;
default:System.out.println("out of bounds");
	}
return t;
}
public void convert(String unit){
switch(unit){
case "nanoseconds":a=t*(pow(10,9));
break;
case "microseconds":a=t*(pow(10,6));
break;
case "miliseconds":a=t*1000;
break;
case "seconds":a=t;
break;
case "minute":a=t/60;
break;
case "hour":a=t/3600;
break;
case "day":a=t/86400;
break;
case "week":a=t/604800;
break;
case "month":a=t/(pow(2.638,6));
break;
case "year":a=t/(pow(3.154,7));
break;
default:System.out.println("out of bounds");
break;
}}
public double gettime(){
return a;}
}

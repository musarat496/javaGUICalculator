
package unit.converter;
import static java.lang.Math.*;
public class energy {
protected double e;
protected double a;
public energy(){}
public void setenergy(double E){
this.e=E;}
public double initial(String iunit){
switch(iunit){
case "gigajoules":e=e*pow(10,9);
return e;
 case "kilowatt-hour":e=e*3600000;
return e;
 case "megajoules":e=e*1000000;
return e;
 case "joules":e=e*1;
return e;
 case "calories":e=e*4.1868;
return e;
 case "BTU":e=e*1055.056;
return e;
 default:System.out.println("out of bounds");
}return e;}
public void convert(String unit){
switch(unit){
case "gigajoules":a=e/pow(10,9);
 break;
 case "kilowatt-hour":a=e/3600000;
 break;
 case "megajoules":a=e/1000000;
 break;
 case "joules":a=e;
 break;
 case "calories":a=e/4.1868;
 break;
 case "BTU":a=e/1055.056;
 break;
 default:System.out.println("out of bounds");
 break;
}}
public double getenergy(){return a;}
}

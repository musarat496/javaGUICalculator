
package unit.converter;
public class velocity {
protected double ve;
protected double a;
public velocity(){}
public void setvelocity(double VE){
this.ve=VE;}
public double initial(String iunit){
switch(iunit){
case "milimeter/second":ve=ve*0.001;
  return ve;
  case "centimeter/second":ve=ve*0.01;
  return ve;
  case "meter/second":ve=ve*1;
  return ve;
  case "kilometer/hour":ve=ve*0.2777777778;
  return ve;
  case "foot/second":ve=ve*0.3048;
  return ve;
  case "knots":ve=ve*0.5147733333;
  return ve;
  case "yards/second":ve=ve*0.9144;
  return ve;
  case "miles/hour":ve=ve/2.237;
  return ve;
  default:System.out.println("out of bounds");
}return ve;}
public void convert(String unit){
switch(unit){
case "milimeter/second":a=ve/0.001;
  break;
  case "centimeter/second":a=ve/0.01;
  break;
  case "meter/second":a=ve;
  break;
  case "kilometer/hour":a=ve/0.2777777778;
  break;
  case "foot/second":a=ve/0.3048;
  break;
  case "knots":a=ve/0.5147733333;
  break;
  case "yards/second":a=ve/0.9144;
  break;
  case "miles/hour":a=ve*2.237;
  break;
  default:System.out.println("out of bounds");
  break;
}}
public double getvelocity(){
return a;}
}


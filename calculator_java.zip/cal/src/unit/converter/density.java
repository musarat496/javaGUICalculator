
package unit.converter;
public class density {
protected double d;
protected double a;
public density(){
}
public void setdensity(double D){
this.d=D;}
public double initial(String iunit){
switch(iunit){
case "gram per cubic centimeter":d=d*1000;
return d;
 case "kilogram per cubic meter":d=d*1;
return d;
 case "gram per litre":d=d*1;
return d;
 case "pound per cubic inch":d=d*27679.904000;
return d;
 default:System.out.println("out of bounds");
}return d;}
public void convert(String unit){
switch(unit){
    case "gram per cubic centimeter":a=d/1000;
 break;
 case "kilogram per cubic meter":a=d;
 break;
 case "gram per litre":a=d;
 break;
 case "pound per cubic inch":a=d/27679.904000;
 break;
 default:System.out.println("out of bounds");
 break;
}}
public double getdensity(){
return a;}
}


package unit.converter;
import static java.lang.Math.*;
public class volume {
protected double v;
protected double a;
public volume(){}
public void setvolume(double V){
this.v=V;}
public double initial(String iunit){
switch(iunit){
case "cubic milimeters":v=v/pow(10,9);
 return v;
 case "cubic centimeters":v=v/pow(10,6);
 return v;
 case "cubic meters":v=v;
 return v;
 case "kilometer cube":v=v*pow(10,9);
 return v;
 case "cubic feet":v=v*0.0283168466;
 return v;
 case "cubic inches":v=v*(1.63871/(pow(10,5)));
 return v;
 case "cubic yards":v=v*0.764554858;
 return v;
 case "cubic miles":v=v*4168181825.4406;
 return v;
 case "litres":v=v*0.001;
 return v;
 case "mililitres":v=v/pow(10,6);
 return v;
 case "gallons":v=v*0.0037854118;
 return v;
 default:System.out.println("out of bounds");
}return v;}
public void convert(String unit){
switch(unit){
case "cubic milimeters":a=v*pow(10,9);
 break;
 case "cubic centimeters":a=v*pow(10,6);
 break;
 case "cubic meters":a=v;
 break;
 case "kilometer cube":a=v/pow(10,9);
 break;
 case "cubic feet":a=v/0.0283168466;
 break;
 case "cubic inches":a=v/(1.63871/(pow(10,5)));
 break;
 case "cubic yards":a=v/0.764554858;
 break;
 case "cubic miles":a=v/4168181825.4406;
 break;
 case "litres":a=v/0.001;
 break;
 case "mililitres":a=v*pow(10,6);
 break;
 case "gallons":a=v/0.0037854118;
 break;
 default:System.out.println("out of bounds");
 break;
}}
public double getvolume(){
return a;}
}
